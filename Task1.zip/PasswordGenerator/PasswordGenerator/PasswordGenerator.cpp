﻿#include <iostream>
#include <string>
#include <sstream>
#include <cstdlib>
#include <fstream>
using namespace std;

int main()
{
    setlocale(LC_ALL, "Ukrainian");
    ofstream myfile;
    myfile.open("example.txt");
    int a = 0, x = 0, r = 0;
    cout << "Чи використовувати великi лiтери? (1 Так/0 Нi): ";
    cin >> a;
    if (a == 1) x += 1;
    cout << "Чи використовувати цифри? (1 Так/0 Нi): ";
    cin >> a;
    if (a == 1) x += 10;
    cout << "Чи використовувати спеціальнi знаки? (Так/Нi): ";
    cin >> a;
    if (a == 1) x += 100;
    cout << "Довжина паролю (цiле додатне число): ";
    cin >> a;
    stringstream ss;
    string result = "";
   



   
    for (; a > 0; a--)
    {
        switch (x) {
        case 1:
            do {
                r = rand() %94+33;
            } while ((r < 65 || r>90) && (r < 97 || r > 122));
            break;
        case 11: 
            do {
                r = rand() %94+33;
            } while ((r < 65 || r > 90)&&(r < 48 || r > 57) && (r < 97 || r > 122));
            break;
        case 111: 
            r = rand() %94+33;
            break;
        case 10: 
            do {
            r = rand() % 94 + 33;
        } while ((r < 48 || r > 57) && (r < 97 || r > 122));
        break;
        case 100: 
            do {
                r = rand() % 94 + 33;
            } while ((r >= 65 && r <= 90) || (r >= 48 && r <= 57)); 
            break;
        case 101:  
            do {
            r = rand() % 94 + 33;
        } while (r >= 48 && r <= 57); 
        break;
        case 110:
            do {
                r = rand() % 94 + 33;
            } while (r >= 65 && r <= 90);
            break;
        default:
            do {
                r = rand() % 94 + 33;
            } while (r < 97 || r > 122);
            break;
        }
        ss << static_cast<char>(r);
        r = 0;
    }
    result = ss.str();
    myfile << result;
    myfile.close();

    cout << "Method 2 Output: " << result << std::endl;

    return 0;
}